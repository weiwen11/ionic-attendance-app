const express = require('express');
const morgan = require('morgan');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const app = express();

// database name UTMSmart
mongoose.connect('mongodb://localhost/UTMSmart', {
  useUnifiedTopology: true,
  useNewUrlParser: true,
  useCreateIndex: true,
}, (err) => {
  if (err) {
    console.log('Error connecting to database.');
  }
});

app.use(morgan('dev')); // log requests in terminal
app.use(bodyParser.urlencoded({ extended: true })); // parse form
app.use(bodyParser.json()); // parse json
app.set('view engine', 'ejs'); // for serving html directly (for website part)

// allow ionic to GET/POST this server
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  next();
});


// routes for website
app.get('/examplepage', (req, res) => { // visit http://localhost:8080/examplepage
  res.render('examplepage'); // will serve views/examplepage.ejs file
});

app.get('/example/anotherpage', (req, res) => { // http://localhost:8080/example/anotherpage
  res.render('anotherpage');
});

app.get('/lecturer', (req, res) => {
  res.render('lecturer');
});

// routes to serve json for both ionic and website
app.get('/api/msg', (req, res) => {
  res.status(200).json({ msg: 'hello' });
});

app.post('/api/form', (req, res) => {
  console.log(req.body.testing);
  res.status(200).json({ msg: 'message received: ' + req.body.testing });
});


// server start
app.listen(8080, () => console.log('app listening on port 8080'));
